import { Link } from "react-router-dom";
import { Module } from "@/types/module";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import WaitlistModal from "./WaitlistModal";
import BoldText from "./BoldText";
import { Sparkles, TrendingUp, Briefcase, Flower2, Wrench, Smartphone } from "lucide-react";
import destinyIcon from "@/assets/destiny-icon.png";
import aiUpgradeIcon from "@/assets/ai-upgrade-icon.png";
import mensCircleIcon from "@/assets/mens-circle-icon.png";
import qualityOfLifeMapIcon from "@/assets/quality-of-life-map-icon.png";
import zoneOfGeniusIcon from "@/assets/zone-of-genius-icon.png";
import geniusOfferIcon from "@/assets/genius-offer-icon.png";
import multipleIntelligencesIcon from "@/assets/multiple-intelligences-icon.png";
import geniusLayerMatchingIcon from "@/assets/genius-layer-matching-icon.png";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";

interface ModuleTileProps {
  module: Module;
  index?: number;
}

const ModuleTile = ({ module, index = 0 }: ModuleTileProps) => {
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);
  const { ref, isVisible } = useScrollAnimation(0.1);

  const statusColor = {
    Live: "bg-green-500/10 text-green-500 border-green-500/20",
    Beta: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    "Coming Soon": "bg-muted text-muted-foreground border-border",
  };

  const categoryIcons = {
    AI: Sparkles,
    Growth: TrendingUp,
    Business: Briefcase,
    Ceremonies: Flower2,
    Tools: Wrench,
    Apps: Smartphone,
    Other: Sparkles,
  };

  const IconComponent = categoryIcons[module.category] || Sparkles;

  // Check if this module should use a custom image
  const useCustomImage = module.slug === "destiny" || module.slug === "intelligence-boost-for-your-ai-model" || module.slug === "mens-circle" || module.slug === "quality-of-life-map" || module.slug === "zone-of-genius" || module.slug === "genius-offer" || module.slug === "intelligences" || module.slug === "genius-layer-matching";
  const customImageSrc = module.slug === "destiny" ? destinyIcon :
    module.slug === "intelligence-boost-for-your-ai-model" ? aiUpgradeIcon :
      module.slug === "mens-circle" ? mensCircleIcon :
        module.slug === "quality-of-life-map" ? qualityOfLifeMapIcon :
          module.slug === "zone-of-genius" ? zoneOfGeniusIcon :
            module.slug === "genius-offer" ? geniusOfferIcon :
              module.slug === "intelligences" ? multipleIntelligencesIcon :
                module.slug === "genius-layer-matching" ? geniusLayerMatchingIcon : null;

  // Use custom route for special modules, standard route for others
  const linkPath = module.slug === "destiny" ? "/destiny" :
    module.slug === "zone-of-genius" ? "/zone-of-genius" :
      module.slug === "genius-offer" ? "/genius-offer" :
        module.slug === "intelligences" ? "/intelligences" :
          module.slug === "mens-circle" ? "/mens-circle" :
            module.slug === "genius-layer-matching" ? "/genius-layer-matching" :
              `/m/${module.slug}`;
  const isComingSoon = module.status === "Coming Soon";
  const isLive = module.status === "Live";

  const handleWaitlistClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsWaitlistOpen(true);
  };

  const cardContent = (
    <Card className={`group h-full overflow-hidden border-border transition-all duration-500 ease-out ${isComingSoon
      ? 'bg-card/50 hover:bg-card/60 cursor-pointer opacity-60'
      : isLive
        ? 'bg-card shadow-md hover:shadow-2xl hover:shadow-accent/20 hover:border-accent hover:-translate-y-2 hover:scale-[1.02] cursor-pointer'
        : 'bg-card shadow-sm hover:shadow-xl hover:shadow-accent/10 hover:border-accent hover:-translate-y-1 cursor-pointer'
      }`}>
      {module.thumbnail_image && (
        <div className={`aspect-video w-full overflow-hidden ${isComingSoon ? 'bg-muted/10' : 'bg-muted'
          }`}>
          <img
            src={module.thumbnail_image}
            alt={module.title}
            className={`w-full h-full object-cover transition-all duration-700 ease-out ${isComingSoon ? 'opacity-20 grayscale' : 'group-hover:scale-110 group-hover:brightness-110'
              }`}
          />
        </div>
      )}
      <div className="p-6 space-y-3">
        <div className="flex flex-col items-center text-center space-y-3">
          {useCustomImage && customImageSrc ? (
            <img
              src={customImageSrc}
              alt={module.title}
              className={`h-16 w-16 object-contain ${isComingSoon ? 'opacity-40 grayscale' : ''
                }`}
            />
          ) : (
            <IconComponent className={`h-16 w-16 ${isComingSoon ? 'text-muted-foreground/40' : 'text-accent'
              }`} />
          )}
          <h3 className={`text-xl font-serif font-semibold transition-all duration-300 ${isComingSoon ? 'text-muted-foreground' : 'group-hover:text-accent group-hover:scale-105'
            }`}>
            <BoldText>{module.title}</BoldText>
          </h3>
        </div>

        <p className={`text-sm line-clamp-2 leading-relaxed text-center ${isComingSoon ? 'text-muted-foreground/60' : 'text-muted-foreground'
          }`}>
          {module.tagline}
        </p>

        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge
              variant="outline"
              className={`${statusColor[module.status]}`}
            >
              {module.status}
            </Badge>

            {module.price && (
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                {module.price}
              </Badge>
            )}

            {module.version && (
              <Badge variant="outline" className="bg-muted/50 text-muted-foreground border-border">
                {module.version}
              </Badge>
            )}
          </div>

          {isComingSoon && (
            <Button
              variant="default"
              size="sm"
              onClick={handleWaitlistClick}
              className="w-full"
            >
              Join Waitlist
            </Button>
          )}
        </div>
      </div>
    </Card>
  );

  return (
    <>
      <div
        ref={ref}
        className={`transition-all duration-700 ${isVisible
          ? 'opacity-100 translate-y-0'
          : 'opacity-0 translate-y-8'
          }`}
        style={{
          transitionDelay: `${index * 100}ms`,
        }}
      >
        <Link to={linkPath} className="block h-full group">
          {cardContent}
        </Link>
      </div>
      {isComingSoon && (
        <WaitlistModal
          isOpen={isWaitlistOpen}
          onClose={() => setIsWaitlistOpen(false)}
          moduleName={module.title}
        />
      )}
    </>
  );
};

export default ModuleTile;
