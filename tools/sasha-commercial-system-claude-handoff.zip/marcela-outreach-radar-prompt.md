# Outreach Radar — build prompt for Marcela

## Setup

1. In Cowork, connect the **Connect Safely** LinkedIn connector to **Marcela's** LinkedIn account.  
2. Connect the **Loop rewards** connector (used for real proof-point numbers in the templates).  
3. Start a new chat and paste everything below the line.

## Two things to know before she starts

**Always open the artifact from the artifact card in the chat.** Opening the saved `.html` from the files folder runs it as a plain local page — no tool access, and its own separate storage, so it looks both broken and empty. Nothing is lost; it's just the wrong context.

**Hit "Save backup" after the first big crawl.** That file is how the data moves to another machine, and the only thing that makes a bad session recoverable.

The prompt below is long on purpose. It encodes the API quirks and design mistakes that cost a full day on Tom's build. Several of them silently produce a tool that *looks* right while being wrong.

---

I want you to build me a persistent artifact called **Outreach Radar** for my LinkedIn account, using the Connect Safely LinkedIn connector. I'm Marcela, and I do partnership outreach for Loop Fans alongside Tom Norwood.

## What Loop Fans is

Loop is a loyalty/rewards platform for local businesses. The flagship product is a **multi-business regional pass** — the Yarra Valley Pass is the live example, with a Chinatown Pass also running. Visitors earn credits for reviews, social content, referrals and spend, and a "trail" mechanic rewards visiting multiple venues (2 \= Explorer, 5 \= Adventurer). Partner density *is* the product: the more venues in a pass, the better it works for everyone in it.

Before writing any message templates, pull the real figures from the Loop connector — `list_businesses`, `get_business`, `get_business_analytics` on the Yarra Valley Pass — so the copy quotes accurate numbers. Also read its current partner list; knowing which venues are already in makes outreach to neighbouring venues much sharper.

## Who we sell to

Four buyer types that are **the same shape**: multiple venues that need visitors to move between them. Only the wrapper differs.

- **Region / DMO** — destination marketing orgs, regional tourism boards, councils  
- **Hospitality group** — multi-venue restaurant/hotel/bar groups  
- **Precinct / association** — chambers of commerce, traders associations, main-street bodies  
- **Event / festival** — events with multiple vendors or venues  
- Secondary: **wine**, **channel partners** (POS, booking platforms), **single venue**

## What to build

A `create_artifact` HTML page — self-contained, light mode, \~28px side padding — that:

1. Crawls my full connection list and caches it  
2. Loads my full conversation history and works out who spoke last, and when  
3. Scores everyone against the ICP model above  
4. Lets me draft, edit and send LinkedIn messages from inside the page  
5. Lets me edit the templates, and promote a good draft back into its template  
6. Has one-file backup/restore with an honest "what's unsaved" indicator

**Tabs.** Recommended (score ≥ 55, *including* people I'm already talking to) · High priority (score ≥ 55 with an existing conversation) · Never messaged · All conversations (catch-all, unfiltered) · You owe a reply (they spoke last) · Waiting on them (I spoke last, 5+ days silent) · Drafts · Sent · Done.

**Each row.** Score badge, ICP label, one-line reason it matched, and a colour-coded conversation line: grey "No conversation — confirmed", amber "unverified", blue "You sent last · 3d ago · 4 msgs", amber "They replied last · 12d ago". Plus attachment, unread, "draft ready" and "high priority" markers. Initials avatars, never profile photos.

**Controls**, grouped and labelled — don't scatter loose buttons: `Crawl: Next 250 · Everything · Stop` / `Refresh: Conversations · Verify visible rows` / `Backup: Save backup · Restore` with a status line and a de-emphasised Reset cache.

---

## Architecture rules — read before writing code

**1\. Bind tools from exactly ONE MCP server.** The artifact's `mcp_tools` list appears to be all-or-nothing. Adding Google Drive tools alongside the LinkedIn ones meant `window.cowork` was **never injected** — the whole bridge silently died and nothing worked. List only the Connect Safely tools. If a second connector is ever needed, publish that change alone and confirm the bridge survives first.

**2\. Never assume `window.cowork` exists when the script runs.** Wait for it — poll `window`, `globalThis`, `self` for \~9s. If it never appears the page is almost certainly running outside the chat panel (opened from the files folder or a browser tab), which also means separate storage, so the cache reads empty. Handle this as a proper offline mode: one short line telling me to open it from the chat card, a **Load a backup file** button so the local copy is still usable for reading and drafting, a Retry, and the explanation tucked behind a "Why?" toggle. Disable crawl/verify/send while offline.

**3\. Backup is a downloaded file. `localStorage` is durable — don't over-engineer this.** It survives artifact rebuilds and even a new artifact id. (I initially believed otherwise and built a Drive auto-sync on that mistake; it triggered rule 1 and solved a problem that didn't exist.) One **Save backup** that downloads JSON, one **Restore** that loads it and **merges rather than replaces**, and a status saying what would be lost in plain terms — "4,210 connections, 3 drafts since last backup", not a timestamp.

**The one genuine loss risk is the storage quota.** Do **not** write `catch(e){}` around `localStorage.setItem`. Once quota is hit every write fails and a large crawl exists only in memory. Detect it, set a flag, show a red warning to save a backup now.

**4\. Build ONE unified people list. Every tab is a filter over it.** Key on `profileUrn`, attach conversation state as a property, include both crawled connections *and* thread participants who aren't in the crawled set. Do not build tabs from separate pools — that's what makes people vanish. This bug recurred three times in different disguises before the model was unified.

**5\. Never remove someone from a view as the only consequence of new information.** If a check reveals an existing conversation, that changes what the row *says*, not whether it exists. Every filtering decision needs a guaranteed destination.

---

## API behaviour — verified against the live connector

**6\. Account and own profile ID.** `list-linkedin-accounts` gives `accountId`. For my own profile ID (needed for message direction), extract it from any conversation URN — `urn:li:msg_conversation:(urn:li:fsd_profile:<MY_ID>,2-...)`. Never hardcode Tom's.

**7\. `get-connections` returns 10 per page regardless of `limit`.** Paginate with `startIndex`; \~8,000 connections is \~824 calls. **Run it inside the artifact via `window.cowork.callMcpTool`, never in chat**, so results never enter conversation context. Cache after every page, resume from stored offset, show progress and a "+N this run" counter.

**8\. Dedupe on the field you actually store.** If records are `{u: profileUrn, …}`, key the Map on `u`. Getting this wrong silently wipes the cache on every batch — the count appears to reset to zero.

**9\. `list-conversations` is DB-first and shallow.** `conversations-sync` writes only a small window (20 threads on Tom's account), so page 1 is *not* the whole inbox even at `count: 100`. The `nextCursor` comes back prefixed `linkedin:` and pages against LinkedIn directly. Follow it, dedupe by `conversationUrn`, stop when a page adds nothing new. **Dangerous if skipped**: people already pitched appear as "never messaged" and get double-contacted.

**10\. Message direction only exists in `get-conversation-messages`.** `list-conversations` returns `senderName: "Unknown"` on every thread and `isSentByOwner: false` even on my own messages — both unusable. Compare `message.senderId === <MY_ID>`. Cache per thread keyed on `lastActivityAt`.

**11\. `conversation-exists` is authoritative per person.** Takes a vanity slug (`profileId`) from the profile URL; skip URN-style URLs. Run it automatically before opening any draft so I can't cold-open someone I'm mid-conversation with. Offer a per-row check and a bulk "verify visible rows".

**12\. When a check finds a thread not in the loaded list, ADOPT it.** Fetch its messages, build a real conversation record, merge it in, tag it recovered. Storing only a boolean makes that person disappear — see rule 5\.

**13\. Don't render profile pictures.** LinkedIn's CDN is hotlink-protected; every image fails in the sandbox. Use initials. Don't cache the URLs either — \~250 chars each across thousands of records will blow the storage quota.

**14\. Sending is the most failure-prone part — build it defensively.**

- **Always set `messagingChannel` explicitly.** The default `"auto"` produced a **422** on Tom's account. Check `get-account-premium-status`: on `NON_PREMIUM` with `hasSalesNavigator: false`, pin `"linkedin_inbox"`. Auto-routing to Sales Navigator without a licence is a known failure.  
- **Fall back across addressing forms:** existing `conversationUrn`, then `recipientProfileUrn`, then `recipientProfileId` (slug), each on `linkedin_inbox` then `auto`, stopping at first success.  
- **Surface the full error from every attempt.** "422" alone is undiagnosable.  
- Confirm before sending, mark sent, re-read the thread so the row flips to "You sent last".  
- **Do not test-send to a real person.** Leave the first send to me and say plainly that this is the one path you couldn't verify. Note that a non-premium account can't always open a *new* thread depending on privacy settings, while replying to an existing one still works.

**15\. `profileUrn` on connections matches `participantUrn` on conversations.** Clean join key — never match on names.

---

## Scoring

ICP weight (Region 10, Group 9, Precinct 9, Event 8, Wine 7, Channel 5, Single venue 4, Advisor/media 2\) × 6, plus: decision-maker title \+14, Australian market \+12, owns partnerships/marketing/commercial \+8, multi-venue words (group, venues, portfolio, collective, association) \+8. Minus 30 for recruiters and job-seekers. Clamp 0–100. Show a short reason string per row.

**Watch regex plurals.** Tom's wine pattern was `/wine\b/`, which does not match "Rochford **Wines**" — the single best prospect scored 34 and landed in the fallback bucket instead of 64\. Use `/wines?\b|winer(y|ies)|vineyards?/` and apply the same care to restaurants, hotels, bars, resorts, distilleries, breweries. Test the classifier against real headlines and show me the output before finalising.

Filter chips per ICP plus Australia-only, text search, and sort by best-fit / newest / oldest / name.

---

## Templates and drafts

**Read my last month of sent messages first** and build templates that match how I actually write — greeting, sign-off, rhythm, formality. Show me what you found before finalising. Tom's spine works structurally, but the wording must be mine:

> "Thanks for connecting\!" → founder/team intro → our system lets businesses reward customers for reviews, social content, referrals → reduces CAC, improves retention → it also helps multiple businesses collaborate and cross-promote to drive cross-visitation → proof point (Tourism East in the Yarra Valley, \~20 local operators) → soft close.

**Templates are editable data, not code.** Plain strings with tokens, user edits stored per ICP in localStorage overriding the defaults:

- `{first}`, `{name}`, `{company}`  
- `[[company: …text… ]]` — renders only when a company was actually parsed. Without it you get "what you're building at your team" whenever parsing fails.

**Draft panel** — a Message / Template toggle sharing one textarea:

- **Message**: the rendered draft. Buttons: Reset to template · **Update template** · Save draft · Send  
- **Template**: the raw template for the ICP in the dropdown. Buttons: Restore default · Save template  
- Mark edited templates in the dropdown (✎) so it's obvious which are customised

**"Update template" matters most.** When I fix the wording of a real draft, that edit should be promotable back into the template — reverse-substitute the person's specifics into tokens (company first, then full name, then first name, since a company can contain a person's name), confirm before overwriting, and show which substitutions will happen. Say honestly in the dialog that a `[[company: …]]` conditional can't be recovered from a finished draft and must be re-added in Template view.

**Company parsing:** match `at X` and `@ X` first, then fall back to `founder|co-founder|owner|ceo|principal of X`. Never bare "of" — "Director of Sales" would yield "Sales". Test against real headlines including ones that should return nothing.

---

## How to work

- **Probe each connector tool once in chat** to confirm its real response shape before building against it — MCP wrappers reshape output relative to the underlying API. Keep bulk crawling inside the artifact so it doesn't burn context.  
- **Syntax-check before every publish.** Extract the `<script>` block and run `node --check`. A stray brace blanks the whole page and is invisible until I open it — this happened twice on Tom's build, once from a duplicated IIFE terminator during an edit.  
- **Test the data pipeline offline.** Run the pure logic (people list, scoring, tab filters, template rendering) in Node against seeded fake data and confirm every tab returns sensible counts. This is how the plural-regex bug was found.  
- **Publish one meaningful change at a time** and confirm it works before layering the next. Most of the pain on Tom's build came from stacking changes then guessing which broke it.  
- **Diagnose before fixing.** Make the page report what it can actually see before shipping a theory. Three wrong fixes went out on Tom's build because the cause was assumed rather than measured — and the real cause turned out to be opening the file from the wrong place.  
- When you're done, tell me plainly which parts you verified against live data and which you wrote from the schema alone.

