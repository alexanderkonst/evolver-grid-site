# Build Your Own LinkedIn ICP Prospector in Claude

A self-serve guide to building an AI tool that searches LinkedIn for your ideal customers, scores them by potential (best first), and lets you connect with one click — right inside Claude.

No code required. Setup takes about 15 minutes.

The cost is $10 per month to run it after the 7 day free trial as you need a Connect Safely account (I am not associated with Connect Safely in any way). But for the amount of time saved and the quality of the connections you’ll build \- I think $10 is well worth it\! 

---

## What you're building

A private, reusable tool (a Claude "artifact") that:

- Runs **multiple LinkedIn searches per ICP** (ideal-customer profile) for you.  
- **Dedupes and scores** every person 0–100 by how good a target they are — role fit, category match, how reachable they are, and location — and ranks the best first.  
- Lets you **connect one-click** from a ranked table, with guardrails so you never trip LinkedIn's limits.  
- **Refreshes its own search terms** based on what actually produced good leads, so you're never re-running the same searches.  
- Works in **Global** or a **single-country** mode (e.g. Australia).

It runs on your own LinkedIn account through a connector called **ConnectSafely**. Set that up first (Part 1), then build the tool (Parts 2–3).

---

## Part 1 — Connect LinkedIn to Claude with ConnectSafely

This is the one thing you must set up first. ConnectSafely is a hosted service that safely bridges Claude and your LinkedIn account. It's genuinely worth it — it's what turns Claude from "gives advice" into "actually runs your outreach."

### Cost

ConnectSafely offers a **7-day free trial**, so you can build and test this for free. After that it's a paid plan. As of mid-2026 their pricing runs from a low-cost **API tier (around $10/month per connected LinkedIn account)** which is the one you need for this tool: [https://connectsafely.ai/pricing](https://connectsafely.ai/pricing)

### Step 1 — Create your account and start the trial

Go to [**https://connectsafely.ai**](https://connectsafely.ai), sign up, and start the free trial. Connect your LinkedIn account inside ConnectSafely when prompted.

### Step 2 — Get your MCP server URL

Open [**https://connectsafely.ai/mcp-server**](https://connectsafely.ai/mcp-server) and copy your personal **MCP server URL**. (This is a private URL tied to your account — don't share it.)

### Step 3 — Add it to Claude Desktop

1. Open the **Claude desktop app**.  
2. Go to **Settings → Connectors**.  
3. Click **Add custom connector** (a.k.a. "Add custom connection").  
4. Paste your **MCP server URL** and save.

That's it — Claude can now see and act on your LinkedIn. You can sanity-check it by asking Claude in a normal chat: *"List my connected LinkedIn accounts."* If it names your account, you're ready.

> Safety note: ConnectSafely is designed to work within LinkedIn's guidelines, but you're still acting as yourself. The tool you're about to build respects LinkedIn's real limits (about **90 connection requests per week** and **300 searches per month** per account). Stay within them.

---

## Part 2 — Customise these bits BEFORE you paste the prompt

The prompt in Part 3 is a template. **Edit the four sections below first** — they're the only parts that change from person to person. Everything else can stay as-is.

PRO TIP \- Use Claude to help you to edit these sections for your own business and customize the prompt below. 

### ✏️ 1\. Your product one-liner

One sentence on what you sell and who you plug into. This helps the tool judge "role fit."

> *Example: "We sell a loyalty & rewards platform for hospitality venues; our best contacts are owners, founders, partnerships leads, and marketing managers."*

### ✏️ 2\. Your ICPs and their search terms

List **3–6 ICPs**. For each, give a name and **6–8 search phrases** (job title \+ category \+ optional seniority words). Replace the examples wholesale with your own market.

> **Example set (a hospitality loyalty product — swap for yours):**  
> 

> - **Hospitality Groups** — `hotel group founder`, `restaurant group owner`, `hospitality group managing director`, `hotels group general manager`, `dining group founder`, `hospitality group partnerships`  
> - **Boutique / Youth Hospitality** — `backpacker hostel group founder`, `boutique hostel owner`, `youth hostel group director`, `boutique hotel group founder`, `poshtel founder`, `budget lifestyle hotel founder`  
> - **Hospitality & Travel Tech** — `hospitality tech founder`, `travel tech partnerships manager`, `hotel tech founder`, `hospitality SaaS partnerships`, `guest experience platform founder`, `booking platform partnerships`  
> - **Destination Marketing & Tourism Boards** — `destination marketing organisation`, `tourism board director`, `regional tourism organisation`, `visitor economy manager`, `city precinct manager`, `tourism partnerships manager`  
> - **Hospitality & Tourism Agencies** — `hospitality marketing agency founder`, `tourism marketing agency director`, `travel PR agency partnerships`, `hospitality branding agency owner`, `destination marketing agency founder`  
> - **Loyalty / Membership Managers** — `hotel loyalty program manager`, `resort group membership manager`, `guest loyalty partnerships`, `hotel group CRM manager`, `hotel rewards program manager`

*Tip: phrases of 3–6 words work best. Include the role words that matter to you (founder, owner, partnerships, GM, director).*

### ✏️ 3\. Region mode

Pick your default: **Global**, or a **single country** (name it, e.g. Australia). You'll get a toggle either way, but this sets the starting mode.

- **Global** \= searches run as written; location doesn't change the score.  
- **Country mode** \= your country's name is appended to searches and people in that country score higher.

### ✏️ 4\. Preferences (optional)

- Results per search (default **35**).  
- Weekly connection cap to warn at (LinkedIn's real limit is **90/week** — leave it unless you have reason to lower it).

---

## Part 3 — The prompt (paste into Claude Cowork)

Open the **Claude desktop app**, start a **Cowork** chat, paste everything in the box below (with your edits from Part 2), and send.

---

Build me a LinkedIn ICP prospecting tool as a persistent Cowork **artifact**. It should run multiple LinkedIn searches per ICP through my connected LinkedIn connector, dedupe and **score** everyone by potential (highest first), and let me **connect one-click**. Follow this spec exactly.

**MY PRODUCT:** \<\<paste your one-liner from Part 2 \#1\>\>

**MY REGION DEFAULT:** \<\<Global — or name your country, e.g. Australia\>\>

**MY ICPs (name \+ search terms):** \<\<paste your ICP list from Part 2 \#2\>\>

### Step 0 — Probe my connector first (don't skip)

I have a LinkedIn connector connected (ConnectSafely). Before building:

1. Call my `list-linkedin-accounts` tool to confirm my account.  
2. Run ONE `search-people` call (any keyword, count 5\) to confirm it works and see the response shape.  
3. Note the **exact fully-qualified tool names** — they're prefixed with my connector's own ID (e.g. `mcp__<my-id>__search-people` and `mcp__<my-id>__send-connection-request`). Wire the artifact's `callMcpTool()` calls to **those exact names**.

The search response looks like: `{ people: [ { profileUrn, firstName, lastName, headline, location, connectionDegree ("1st"/"2nd"/"3rd+"), currentPosition, profileUrl } ], pagination, hasMore }`. `send-connection-request` takes `{ profileUrn }` (preferred) or `{ profileId }`. **Respect these limits:** 300 searches per account per month; **90 connection requests per week** (resets Monday 00:00 UTC).

### Step 1 — Scoring (deterministic, transparent, 0–100)

For each person, show the score with a hover breakdown:

- **ICP keyword match:** strong keyword in headline \= 40, weak keyword \= 20, else 0 (pick the best-matching ICP if found by more than one search).  
- **Role fit:** founder/co-founder/owner/CEO/managing director/principal \= 30; partnerships/business development/alliances \= 28; general manager/GM/director/head of/VP \= 18; else 5\.  
- **Reachability:** 2nd degree \= 15, 1st \= 8, 3rd+ \= 3\.  
- **Region location:** person is in my selected region \= 15, else 3 (see region toggle below).  
- **Penalty:** headline mentions open-to-work / student / intern / recruiter / talent acquisition \= −15. Clamp 0–100. Default sort \= score descending. Treat score ≥ 60 as "high-quality."

### Step 2 — The artifact UI

- **Section 1 — Choose ICPs & run:** checkbox chips for each ICP; a "results per search" number (default 35); a note showing how many of the 300/month searches a run will use; **Run searches**, **Clear results**, and **↻ Refresh search terms** buttons; a collapsible "Edit search terms" panel with an editable textarea per ICP.  
  - Running fires each enabled term via `callMcpTool(search-people, {keywords, count})` sequentially with a progress bar, dedupes by `profileUrn`, scores, and renders a ranked table live.  
- **Section 2 — Filter & connect:** filters for ICP, min-score slider, connection degree, region-only, hide-already-requested, and a text filter; a live "X / 90 this week" counter.  
- **Ranked table:** rank, colour-coded score badge (hover \= breakdown), name (links to profile), headline, location, degree, ICP tag, action button. Sortable columns.

### Step 3 — Region toggle (Global ⇄ my country)

Add a **Region** switch with **Global** and \*\*\<\>\*\* modes, defaulting to my region above.

- **Country mode:** append my country's name to each search term when running, and the region-location bonus applies to that country's locations; add a "this country only" filter.  
- **Global mode:** run terms as-is; region-location bonus is neutral.  
- Remember the choice in localStorage.

### Step 4 — One-click Connect via a background queue (important)

Do NOT send synchronously and re-render the whole table (that resets buttons). Instead:

- Clicking **Connect** instantly marks that person **Queued…** and returns immediately, so I can click many in a row.  
- A background worker processes the queue **one at a time**: Queued… → Sending… → **Requested**, updating only that single row.  
- Send with `{ profileUrn }`, no note (one-click). On success mark Requested \+ timestamp; on failure show a **Retry** button (hover \= reason).  
- Enforce the 90/week cap counting queued \+ sent; block and warn before overshooting. Counter resets Monday 00:00 UTC.

### Step 5 — Refresh search terms \+ auto-refresh

Track per-term performance (new people found \+ high-quality count). The **↻ Refresh search terms** button rewrites each enabled ICP's terms based on the top performers (use `window.cowork.askClaude` for generation, with a deterministic recombination fallback), and **never repeats an already-run term** (keep a used-terms ledger in localStorage). Add an **"Auto-refresh terms after each run"** checkbox (on by default). Refreshing costs no search budget — only running does.

### Step 6 — Persistence & tech notes

- Persist results, connect history, sent timestamps, term stats, used terms, and settings in `localStorage`.  
- Inside the artifact, `callMcpTool` returns `{content, structuredContent, isError}` — read `r.structuredContent ?? JSON.parse(r.content[0].text)`.  
- Self-contained HTML, light mode, inline CSS/JS. Build it as a persistent artifact I can reopen.

Confirm my connector's exact tool names from Step 0, then build it.

---

## Part 4 — How to use it day to day

1. **Pick your ICPs** (checkboxes) and hit **Run searches.** Watch the ranked list build — best-fit people at the top.  
2. **Filter** to what you want (e.g. min score 60, 2nd-degree only, your country only).  
3. **Connect** — click down the list. Each click queues instantly; requests send in the background so you never wait or lose your place.  
4. When a run finishes, terms **auto-refresh**, so your next run hits fresh people. Repeat.  
5. Keep an eye on the **X / 90 this week** counter — that's LinkedIn's real weekly connection limit.

Because it saves everything in your browser, you can close it and pick up later. Searches draw down your 300/month LinkedIn budget; refreshing terms and connecting do not.

---

## Troubleshooting

- **"Claude can't find my LinkedIn."** Re-check Part 1, Step 3 — the MCP URL must be added under Settings → Connectors, and your LinkedIn must be connected inside ConnectSafely.  
- **Searches return nothing / errors.** You may have hit the 300/month search cap, or your ConnectSafely trial/plan lapsed. Check your ConnectSafely dashboard.  
- **Connect says "Retry."** LinkedIn briefly rejected it (often rate-related). Wait and retry, and make sure you're under 90 for the week.  
- **Want different scoring?** Tell Claude in the same chat, e.g. *"weight role fit higher"* or *"add 'coworking' as a strong keyword for ICP 2,"* and it'll update the artifact.

