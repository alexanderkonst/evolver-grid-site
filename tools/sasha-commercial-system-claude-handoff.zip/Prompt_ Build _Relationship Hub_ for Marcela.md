# **Prompt: Build "Relationship Hub" for Marcela**

Paste everything below into a fresh Claude (Cowork) session on Marcela's account. She has the **Connect Safely** (LinkedIn) and **Gmail** connectors.

---

Build me a persisted, live HTML **artifact** called **Relationship Hub** — a lightweight personal CRM over my **email (Gmail)** and **LinkedIn** conversations. It should let me label contacts, see who owes a reply, and send follow-ups. Save all my labels/notes/snoozes locally in the artifact and cache the fetched conversations so it doesn't re-hit my connectors on every open.

**Before writing any code, probe both connectors live** (call each tool once) to confirm the exact response shapes, then build the parser around what you actually see. Don't assume field names.

## **Identity & connectors (discover mine — don't hardcode anyone else's)**

* **Gmail connector**: tools like `search_threads`, `get_thread`, `create_draft`. My email address is the Gmail account owner (e.g. `marcela@loop.fans`). Set `OWNER_EMAILS = [my address]` and `TEAM_EMAILS = [teammates to exclude as contacts, e.g. tom@loop.fans]`.  
* **Connect Safely (LinkedIn) connector**: `list-linkedin-accounts`, `list-conversations`, `get-conversation-messages`, `conversations-send-message`. Call `list-linkedin-accounts` to get **my accountId**.  
* **My LinkedIn owner profile id** \= the first `urn:li:fsd_profile:XXXX` id embedded inside every `conversationUrn` (it's the mailbox owner). Extract it with a regex; it also matches the participant whose name is me.  
* **Direction detection (critical):** a LinkedIn message is "mine" if `senderId === ownerProfileId` OR `senderName` equals my name. **`isSentByOwner` is unreliable — do not use it.** `get-conversation-messages` returns newest-first.  
* Connector calls in the artifact go through `window.cowork.callMcpTool(name, args)`; parse results as `r.structuredContent ?? JSON.parse(r.content[0].text)`. AI calls use `window.cowork.askClaude(prompt, [dataObj])`.

## **Loading the data**

**Email (build straight from search results — do NOT call `get_thread` per thread; \~200 calls chokes Gmail and leaves email nearly empty):**

* Query `in:sent newer_than:120d`, `pageSize:50`, paginate up to \~10 pages. `in:sent` cleanly excludes newsletters.  
* For each thread: sort its returned messages by date. Collect **every external address** from sender/to/cc, excluding `OWNER_EMAILS`, `TEAM_EMAILS`, and junk (regex for `no-reply`, `notifications@`, `mailer`, `newsletter`, `beehiiv`, `@mail.`, etc.).  
* **Create one contact per external participant** (so people I'm introduced to — cc'd or added as a recipient — aren't lost behind the introducer). For each: `ts` \= latest message date; `lastMine` \= latest message sender is me; `theyReplied` \= that specific address appears as a sender; keep `threadId`, latest `lastMsgId` (for replies), and subject.

**LinkedIn (gentle — avoid any block risk):**

* `list-conversations` (my accountId, `count:50`), paginate up to \~5 pages — this is DB-first and low risk.  
* The rate-limit-sensitive call is `get-conversation-messages`. Only fetch it for the most recent conversations up to a cap `LI_MSG_CAP = 160`, **strictly serial (one at a time) with a randomised \~0.9–1.5s gap.** Never burst.  
* Other participant \= the one who isn't me. From last \~8 messages compute `lastMine`, `theyReplied`, `outCount`, and `firstTouch` \= a single outbound message with no reply (a cold first-touch handoff — tag it "1st-touch").

## **Merge / dedupe (stable keys — this matters for persistence)**

Group **every** source under one stable key: if the name has 2+ words → `"nm:"+normalizedName` (merges the same person across email \+ LinkedIn); otherwise the source's own key (`"em:"+email` or `"li:"+profileId`). This dedupes people who appear in many threads (e.g. `partner@company`) into **one** card. Keys must be stable across syncs or snooze/close/labels won't stick. Add a defensive fallback: if a contact's primary key has no saved state, adopt state stored under any of its source-identity keys.

## **Local storage (persist everything)**

* `relhub_v1`: per-contact `{category, note, snoozeUntil, closed, followedUpAt, autoSnoozeTs, autoSnoozed, updatedAt}`.  
* `relhub_ai_v2`: AI triage verdicts keyed by contact key `{ts, state, reason}` (invalidate when the latest-message ts changes).  
* `relhub_data_v1`: cached fetched sources `{savedAt, email:[...], li:[...]}`.  
* **On open, load from the cache and render instantly with zero connector calls.** A banner shows how old the saved data is with two buttons: **⟳ Sync recent** and **Full resync**.

## **Sync behaviour**

* **Full resync / first run:** fetch everything and **stream cards in progressively** — email first (fast, appears in seconds), then LinkedIn trickling in serially. Show a live "reading X/Y" progress indicator. Save to cache at the end.  
* **Sync recent (incremental, default after first run):** only fetch what changed since last sync — email `in:sent newer_than:{days since last sync}d`; LinkedIn only conversations whose `lastActivityAt` is newer than last sync (message-fetch just those). Merge new rows into the cached rows by `threadId` / `conversationUrn` (newest wins), then render once (no streaming flicker).

## **Follow-up logic (read the messages — don't just look at who replied last)**

* **Status:** `wait` (I sent last, awaiting their reply), `turn` (they replied, I haven't), `ok`.  
* **Windows** (only after which a nudge is even considered): when awaiting their reply — lead 4d, client 7d, investor 6d, personal 14d, unlabeled 5d, promotional never. When it's my turn — 2d.  
* **Content triage:** for each structurally-due contact, read its recent messages and classify into one of `meeting_scheduled` / `awaiting_them` / `closed` / `needs_followup`. **Only `needs_followup` actually flags a follow-up.** Cache verdicts.  
  * **Deterministic booking check FIRST** (don't rely on the model): regex the last several messages for booking signals — `booked`, `calendly`/`cal.com`, `invite`, `see you (then/on/Tuesday…)`, `looking forward to (our/the) call/chat/meeting`, `scheduled/confirmed for`, etc. If found → `meeting_scheduled`, **unless** I asked a fresh question *after* the booking that's gone unanswered (then `needs_followup`). Only fall back to `askClaude` for genuinely ambiguous threads.  
  * **Auto-snooze booked meetings for 14 days** (once per message): they drop out of the active list and resurface afterward for a post-meeting follow-up. Show them in the Snoozed tab badged "📅 Meeting booked". Never override a longer manual snooze or a Close.  
* **Smart "Follow-up first" sort:** rank by **how long since I was in contact (oldest / most-overdue first)**, plus a bump for "your turn", a category weight (investor/lead/client higher, promotional negative), a big bump for just-back-from-snooze, and a light hotness tiebreak. Recent contacts must NOT jump to the top.

## **UI**

* Header \+ stats: **Active, Need follow-up, Leads, Clients, Snoozed, Closed** (exclude snoozed/closed from active counts).  
* Tabs: **List**, **Pipeline** (kanban columns by category with drag-and-drop to re-tag), **Snoozed** (resurface date \+ "Wake now", filterable by tag), **Closed** (archived, "Reopen", **keeps its tag** and filterable by category so I can find e.g. closed Investors).  
* Controls: search box, category filter, channel filter, sort (Follow-up first / Hottest / Recent / Name), "Needs follow-up" toggle.  
* Contact card: avatar, name (linked to LinkedIn profile), headline, channel chips (LinkedIn / Email), status chip (Awaiting reply · Nd / Your turn · Nd / Active), AI chip (📅 Meeting booked / ⏳ Their court / ✔ Closed / ⋯ checking), "1st-touch" tag, "Back from snooze" tag, a **category dropdown** (lead / client / investor / personal / promotional), a priority bar, and last-activity.  
* **Always-visible action bar on every card** (no click-to-expand): 👁 **Preview** (expand the last \~14 messages inline), 🧠 **Summarise** (one-click `askClaude` recap: who they are, their org, what was discussed, the next step), a **notes** field, ✨ **Smart timing** (`askClaude` per-contact timing suggestion), ✍️ **Draft follow-up**, **💤 Snooze** dropdown (3d / 1wk / 2wk / 1mo), **Mark done**, **✖ Close**.  
* **Draft follow-up:** read the thread, `askClaude` for a warm, concise, low-pressure 2–4 sentence follow-up in my voice (I'm at Loop — a rewards/loyalty platform for tourism & hospitality; sign off as me), shown in an **editable** textarea. Then:  
  * **LinkedIn →** send directly via `conversations-send-message` (`messagingChannel:"linkedin_inbox"`, pass the `conversationUrn`).  
  * **Email →** there is no send tool, so create a Gmail **draft** via `create_draft` (reply to the latest message id) for me to send from Gmail. Label the button honestly.

## **Build/quality notes**

* Self-contained, single HTML file, **light mode**, no external storage (localStorage only). Render progressively; cache connector reads.  
* Watch the gotchas that bit the first build: `search_threads` returns a **partial/stale** slice of a thread's messages (that's why we build per-thread from what search returns and don't trust it as a full history); the LinkedIn `isSentByOwner` flag is wrong; grouping must dedupe by a stable key or you get duplicate flashing cards and lost snooze state.  
* Ask me a couple of clarifying questions only if something is genuinely ambiguous (e.g. my exact Gmail address / who counts as a teammate), then build it.

When it's done, publish it as a persisted artifact and give me the Sync buttons so I can do the first Full resync myself.

